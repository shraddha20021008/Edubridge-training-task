package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CourseOneToOne {
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) //autoincrement
	private int cid;
	
	@Column(length=30,nullable = false)
	private String sname;
	
	@Column(name="sfees" , nullable = false)
	private float cfees;
	
	@OneToOne(mappedBy = "cobj")
	private StudentOneToOne sobj;
	
	public CourseOneToOne() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CourseOneToOne(String sname, float cfees) {
		super();
		this.sname = sname;
		this.cfees = cfees;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public float getCfees() {
		return cfees;
	}

	public void setCfees(float cfees) {
		this.cfees = cfees;
	}

	
	
	public StudentOneToOne getSobj() {
		return sobj;
	}

	public void setSobj(StudentOneToOne sobj) {
		this.sobj = sobj;
	}

	@Override
	public String toString() {
		return "CourseOneOToOne [cid=" + cid + ", sname=" + sname + ", cfees=" + cfees + "]";
	}
	
	
	
     
}
