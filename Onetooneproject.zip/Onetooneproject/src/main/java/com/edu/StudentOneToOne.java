package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class StudentOneToOne {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int sid;
	
	@Column(name="sname" , length = 50, nullable = false)
	  private String sname;
	  
	@OneToOne 
	//private CourseOneOToOne cobj; //generate setter and getter method
	@JoinColumn(name="cid")
	private CourseOneToOne cobj;
	public StudentOneToOne() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentOneToOne(String sname) {
		super();
		this.sname = sname;
	}
	
	
	public CourseOneToOne getCobj() {
		return cobj;
	}
	public void setCobj(CourseOneToOne cobj) {
		this.cobj = cobj;
	}
	@Override
	public String toString() {
		return "StudentOneToOne [sid=" + sid + ", sname=" + sname + "]";
	}
	  
	  
}
