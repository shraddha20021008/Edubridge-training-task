package com.edu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

	public static void main(String[] args) {
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		config.addAnnotatedClass(Project.class);
		config.addAnnotatedClass(EmployeeProject.class);
		
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		
		Project pr=new Project(1,"Angular");
		Project pr1=new Project(2,"Java");
		
		EmployeeProject emp=new EmployeeProject(1234,"Sam");
		EmployeeProject emp1=new EmployeeProject(3456,"Ram");
		
		List<Project> plist=new ArrayList<Project>();
		plist.add(pr1);
		plist.add(pr);
		
		List<EmployeeProject> elist=new ArrayList<EmployeeProject>();
		elist.add(emp);
		elist.add(emp1);
		
		pr.setEmployeeproject(elist);
		emp.setProject(plist);
		
		session.save(emp);
		session.save(emp1);
		session.save(pr);
		session.save(pr1);
		tx.commit();
		session.close();
		

	}

}
