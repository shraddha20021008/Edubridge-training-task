package com.edu;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Project {
	@Id
      private int pid;
	@Column(name="pname",length=50,nullable = false)
      private String pname;
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@ManyToMany//(mappedBy = "project")
	private List<EmployeeProject> employeeproject;
	public Project(int pid, String pname) {
		super();
		this.pid = pid;
		this.pname = pname;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
	
	public List<EmployeeProject> getEmployeeproject() {
		return employeeproject;
	}
	public void setEmployeeproject(List<EmployeeProject> employeeproject) {
		this.employeeproject = employeeproject;
	}
	@Override
	public String toString() {
		return "Project [pid=" + pid + ", pname=" + pname + "]";
	}
      
      
}
