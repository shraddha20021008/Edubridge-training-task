package com.edu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.edu.Course;
import com.edu.Student;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration conn=new Configuration();
	     conn.configure("hibernate.cfg.xml");
	     conn.addAnnotatedClass(Course.class);
	     conn.addAnnotatedClass(Student.class);
	     
	     SessionFactory sf=conn.buildSessionFactory();
	     Session session=sf.openSession();
	     Transaction tx=session.beginTransaction();
	     
	     Course c=new Course("E&C");
	     
	    
	     Student s1=new Student("Riya");


	     List<Student>list=new ArrayList<Student>();
	     list.add(s1);
	
	     c.setStulist(list);
	     
	     
	     session.save(c);
	     tx.commit();
	     session.close();
	}

}
