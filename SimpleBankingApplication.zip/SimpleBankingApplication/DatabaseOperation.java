


/*import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
*/
import java.util.Scanner;


public class DatabaseOperation {
  
//private static Connection conn;
 // private static Statement stmt;
// private static PreparedStatement pst;
  //private static String sql;
 // private static ResultSet rs;
  private static Scanner sc = new Scanner(System.in);
  

  private static double balance=0;

	public static void checkBalance() {
		 System.out.println("Your current balance is $" + balance);
		
	}

	public static void deposit() {
		 Scanner sc = new Scanner(System.in);
		    System.out.print("Enter the amount to deposit: $");
		    double amount = sc.nextDouble();
		    balance += amount;
		    System.out.println("$" + amount + " has been deposited to your account.");
		    checkBalance();		
	}

	public static void withdraw() {
		 Scanner sc = new Scanner(System.in);
		    System.out.print("Enter the amount to withdraw: $");
		    double amount = sc.nextDouble();
		    if (amount > balance) {
		      System.out.println("Insufficient funds.");
		    } else {
		      balance -= amount;
		      System.out.println("$" + amount + " has been withdrawn from your account.");
		    }
		    checkBalance();
		
	}
	


	}

		
